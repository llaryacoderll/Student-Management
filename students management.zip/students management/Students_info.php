<?php include"header.php";?>
<div class="container mt-5 pt-4 mb-5 pb-5">
<form method="POST" action="classes/addpersonal.php">
<div class="container mt-5 pt-4 mb-5 pb-5">
<h2>Personal Inoformation</h2>
  <div class="form-group">
    <label for="exampleInputEmail1">Email Id</label>
    <input type="email" class="form-control" name="EML"  aria-describedby="emailHelp" placeholder="Email Id">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Phone Number</label>
    <input type="number" class="form-control" name="NUM"  aria-describedby="emailHelp" placeholder="Phone number">
  </div>
  <div class="form-group">
    <label for="inputAddress">Address</label>
    <input type="text" name="ADS" class="form-control" id="inputAddress" placeholder="">
  </div>
  <button id="snackbar" type="submit" class="btn btn-primary">Submit</button>
</form>
</div>
</body>
</html>