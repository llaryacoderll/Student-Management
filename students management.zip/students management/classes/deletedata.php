<?php include'config.php';?>
<?php

$id=$_GET['id'];


echo"$id ";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
  }
  
  // sql to delete a record
  $sql = "DELETE FROM add_students WHERE id_students='$id'";
  $sql1 = "DELETE FROM personal_info WHERE id_students='$id'"; 
  
  if (mysqli_query($conn, $sql)) {
      echo "Record deleted successfully";
    } else {
        echo "Error deleting record: " . mysqli_error($conn);
    }
    
    if (mysqli_query($conn, $sql1)) {
        echo "Record deleted successfully";
    } else {
        echo "Error deleting record: " . mysqli_error($conn);
    }
    
    header("location: ../delete.php?data=yes");
  mysqli_close($conn);
 
?>