<?php
$servername = "localhost";
$username = "root";
$password = "admin";
$dbname = "students";
?>