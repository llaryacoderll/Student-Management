
<?php include'config.php';?>
<?php

$id= $_GET['id']; 
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT id_students, firstname, semster,gender,branch FROM add_students WHERE id_students='$id'";
$result = $conn->query($sql);
$sql1 = "SELECT email ,addres, phone FROM personal_info WHERE id_students='$id'";
$result1 = $conn->query($sql1);


if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    $NAM=$row["firstname"];   
  }
} else {
  echo "0 results";
}
if ($result1->num_rows > 0) {
  // output data of each row
  while($row = $result1->fetch_assoc()) {
    $EML=$row["email"];
    $ADS=$row["addres"];
    $PHN=$row["phone"];
  }
} else {
  echo "0 results";
}


$conn->close();



?>




<html>
    <head>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
	<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    </head>
    <body>
    <div class="container mt-5 pt-4 mb-5 pb-5" style="background-color: #a3c2c2;">
<form method="get" action="update.php">
    <h1> Students</h1>
  <div class="form-group">
    <label for="exampleInputEmail1">Student Id</label>
    <input type="text" name="SID" class="form-control" value="<?php echo"$id"; ?>"  aria-describedby="emailHelp" placeholder="">
    </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Students Name</label>
    <input type="text" name="NM" class="form-control" value="<?php echo"$NAM"; ?>">
  </div>
  <div class="form-group">
  <label for="exampleFormControlSelect1">Semster</label>
  <select class="form-control" name="SEM" >>
    <option>1</option>
    <option>2</option>
    <option>3</option>
    <option>4</option>
    <option>5</option>
    <option>6</option>
    <option>7</option>
    <option>8</option>
  </select>
  </div>
  <div class="form-group mt-2">
  <select class="form-control" name="BRH" >
    <option>Select Branch</option>
    <option>Inoformation Technology</option>
    <option>Computer Science and Engineering</option>
    <option>Civil Engineering</option>
    <option>Electronics and Telecommunication Engg</option>
    <option>Mechanical Engineering</option>
  </select>
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Email Id</label>
    <input type="email" class="form-control" name="EML" value="<?php echo"$EML"; ?>" aria-describedby="emailHelp" placeholder="Email Id">
  </div>
  <div class="form-group">
    <label for="exampleInputEmail1">Phone Number</label>
    <input type="number" class="form-control" name="NUM" value="<?php echo"$PHN"; ?>"   aria-describedby="emailHelp" placeholder="Phone number">
  </div>
  <div class="form-group">
    <label for="inputAddress">Address</label>
    <input type="text" name="ADS" value="<?php echo"$ADS"; ?>" class="form-control" >
  </div>
  <button id="snackbar" type="submit" class="btn btn-primary">Submit</button>
</div>
</form>
</div>
</body>
</html>