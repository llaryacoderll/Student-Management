<?php include'config.php';?>
<?php
    $SID=$_POST['SID'];
    $NM=$_POST['NM'];
    $SEM=$_POST['SEM'];
    $GDR=$_POST['GDR'];
    $BRH=$_POST['BRH'];
?>

<?php

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

$sql = "INSERT INTO add_students VALUES ('$SID', '$NM', '$SEM','$GDR','$BRH')";

if (mysqli_query($conn, $sql)) {
  header("location: ../index.php");
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);


?>