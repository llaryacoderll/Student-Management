<?php include'config.php';?>
<?php
    $EML=$_POST['EML'];
    $NUM=$_POST['NUM'];
    $ADS=$_POST['ADS'];
?>

<?php

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

$sql = "INSERT INTO personal_info VALUES ('$EML','$NUM','$ADS')";

if (mysqli_query($conn, $sql)) {
  header("location: ../index.php");
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);


?>