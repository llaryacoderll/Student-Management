<?php include'config.php';?>
<?php

$id=$_GET['SID'];
$NM=$_GET['NM'];
$SEM=$_GET['SEM'];
$BRH=$_GET['BRH'];

echo"$id $NM $SEM";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "UPDATE add_students SET firstname='$NM' , semster='$SEM' , branch='$BRH'  WHERE id_students='$id'";

if ($conn->query($sql) === TRUE) {
    header("location: ../getstudent.php");
  echo "Record updated successfully";
} else {
  echo "Error updating record: " . $conn->error;
}

$conn->close();
?>