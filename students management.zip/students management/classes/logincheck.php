<?php
   include("config.php");
 
$email= $_GET['email']; 
$pass= $_GET['pass']; 
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM admin_table WHERE username='$email' and passcode='$pass'";
$result = $conn->query($sql);

if ($result->num_rows >0) {
       header("location: ../index.php");
      }else {
         $error = "Your Login Name or Password is invalid";
         echo "$error";
      }

?>