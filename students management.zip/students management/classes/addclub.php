<?php include'config.php';?>
<?php
    $SID=$_POST['SID'];
    $NM=$_POST['NM'];
    $fess=$_POST['fess'];
    
?>

<?php

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

$sql = "INSERT INTO club VALUES ('$SID', '$NM', '$fess')";

if (mysqli_query($conn, $sql)) {
  header("location: ../index.php");
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);


?>