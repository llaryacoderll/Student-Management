
<?php include"studentheader.php";?>
<div class="container mt-5 pt-4 mb-5 pb-5">
<form method="POST" action="classes/addstudent.php">
    <h1> Students</h1>
  <div class="form-group">
    <label for="exampleInputEmail1">Student Id</label>
    <input type="text" name="SID" class="form-control"  aria-describedby="emailHelp" placeholder="Students Id">
    </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Students Name</label>
    <input type="text" name="NM" class="form-control" placeholder="Name">
  </div>
  <div class="form-group">
  <label for="exampleFormControlSelect1">Semster</label>
  <select class="form-control" name="SEM">
    <option>1</option>
    <option>2</option>
    <option>3</option>
    <option>4</option>
    <option>5</option>
    <option>6</option>
    <option>7</option>
    <option>8</option>
  </select>
  </div>
  <div class="form-check form-check-inline">
    <input class="form-check-input" type="radio" name="GDR" id="inlineRadio1" value="Male">
    <label class="form-check-label" for="inlineRadio1">Male</label>
  </div>
  <div class="form-check form-check-inline">
    <input class="form-check-input" type="radio" name="GDR" id="inlineRadio2" value="Female">
    <label class="form-check-label" for="inlineRadio2">Female</label>
  </div>
  <div class="form-group mt-2">
  <select class="form-control" name="BRH">
    <option>Select Branch</option>
    <option>Inoformation Technology</option>
    <option>Computer Science and Engineering</option>
    <option>Civil Engineering</option>
    <option>Electronics and Telecommunication Engg</option>
    <option>Mechanical Engineering</option>
  </select>
  </div>
  <button id="snackbar" type="submit" class="btn btn-primary">Submit</button>
</div>
</form>
</div>
</body>
</html>