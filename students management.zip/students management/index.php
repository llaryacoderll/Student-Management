<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" type="text/css" href="assets/css/style1.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
	<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">S.M.S</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="studensts.php">Students</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="Students_info.php">Stud Info</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="students_update.php">Update</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="delete.php">Delete</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="getstudent.php">Records</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="serachstudent.php">Serach</a>
      </li>
    </ul>
  </div>
  <li class="nav-item">
        <a class="nav-link" href="login.php">Login</a>
      </li>
</nav>
<div class="containe" >
  <div class="row">
    <div class="col">
      <img src="img/1393334.webp" width="1550px" height="600px">
    </div>
  </div>
</div>
</body>
</html>