<?php include"C:/xampp/htdocs/students management/header.php";?>
<?php include 'classes/config.php'; ?>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="C:/xampp/htdocs/students management/assets/css/style1.css">
    </head>
    <body>
        <?php
        if(array_key_exists("data",$_GET))
        {
        ?>
        <div class="alert alert-success alert-dismissible container mt-3" role="alert">
            Record Delete successfully
            <button type="button" class=" btn btn-close float-end" data-bs-dismiss="alert" >X</button>
        </div>
        <?php } ?>
        <div class="container mt-5 mb-5 pb-5" style="background-color: #a3c2c2;">
            <div class="col">
                <h1><center>Delete Your Details</center></h1>
                <form method="get" action="classes/deletedata.php">
                    <div class="form-group">
                        <label>Students ID</label>
                        <input type="text" name="id" class="form-control" placeholder="Name" id="id">
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
<?php
echo "<script>";
echo "function load() {
  window.scrollTo({
    top: 515,
    });
}
window.onload = load;";
echo "</script>";   
    ?>
</html>
