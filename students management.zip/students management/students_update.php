<?php include"C:/xampp/htdocs/students management/header.php";?>
<?php include 'classes/config.php'; ?>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="C:/xampp/htdocs/students management/assets/css/style1.css">
    </head>
    <body>
        <div class="container mt-5 mb-5 pb-5" style="background-color: #a3c2c2;">
            <div class="col">
                <h1><center>Update Your Details</center></h1>
                <form method="get" action="classes/dataupdate.php">
                    <div class="form-group">
                        <label>Students ID</label>
                        <input type="text" name="id" class="form-control" placeholder="Name" id="id">
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
      
    </body>
</html>
