<html>
  <head>
<link rel="stylesheet" type="text/css" href="assets/css/style1.css">
<style>
table {
  border-collapse: collapse;
  width: 100%;
}

th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
  background-color: 	 #476b6b;
  color: white;
}
</style>
  </head>
<?php include"C:/xampp/htdocs/students management/header.php";?>
<?php include 'classes/config.php'; ?>
<div class="container mt-5 mb-5 pt-5 pb-5" style="background-color:#a3c2c2 ; " ">
    <h1>Students Details</h1>
    
<?php
echo "<table style='border: solid 0px black ; border-collapse: collapse; width: 100%;'>";
 echo "<tr><th> student Id</th><th>Name</th><th>Semster</th><th>Gender</th><th>Branch</th></tr>";

class TableRows extends RecursiveIteratorIterator {
    function __construct($it) {
        parent::__construct($it, self::LEAVES_ONLY);
    }

    function current() {
        return "<td style='width: 150px; border: 1px solid black;'>" . parent::current(). "</td>";
    }

    function beginChildren() {
        echo "<tr>";
    }

    function endChildren() {
        echo "</tr>" . "\n";
    }
}

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $conn->prepare("SELECT id_students, firstname, semster,gender,branch FROM add_students");
    $stmt->execute();

    // set the resulting array to associative
    $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);

    foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
        echo $v;
    }
}
catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}

echo "</table>";

echo "<br><br><h1>Personal Info</h1>";
echo "<table style='border: solid 0px black ; border-collapse: collapse; width: 100%;'>";
 echo "<tr><th> Email</th><th>Phone</th><th>Address</th></tr>";

class TableRows11 extends RecursiveIteratorIterator {
    function __construct($it) {
        parent::__construct($it, self::LEAVES_ONLY);
    }

    function current() {
        return "<td style='width: 150px; border: 1px solid black;'>" . parent::current(). "</td>";
    }

    function beginChildren() {
        echo "<tr>";
    }

    function endChildren() {
        echo "</tr>" . "\n";
    }
}

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $conn->prepare("SELECT email, phone, addres FROM personal_info");
    $stmt->execute();

    // set the resulting array to associative
    $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);

    foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
        echo $v;
    }
}
catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}

echo "</table>";
echo "<br><br><h1>Club Info</h1>";

echo "<table style='border: solid 0px black ; border-collapse: collapse; width: 100%;'>";
 echo "<tr><th> Student Id</th><th>Club Name</th></tr>";

class TableRows12 extends RecursiveIteratorIterator {
    function __construct($it) {
        parent::__construct($it, self::LEAVES_ONLY);
    }

    function current() {
        return "<td style='width: 150px; border: 1px solid black;'>" . parent::current(). "</td>";
    }

    function beginChildren() {
        echo "<tr>";
    }

    function endChildren() {
        echo "</tr>" . "\n";
    }
}

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $conn->prepare("SELECT id_students, club_name FROM club");
    $stmt->execute();

    // set the resulting array to associative
    $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);

    foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
        echo $v;
    }
}
catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}



$conn = null;
echo "</table>";


echo "<script>";
echo "function load() {
  window.scrollTo({
    top: 515,
    });
}
window.onload = load;";
echo "</script>"; 
?>
</div>
</html>