<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" type="text/css" href="assets/css/style1.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
	<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">S.M.S</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Students</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Attendence</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Records</a>
      </li>
    </ul>
  </div>
  <button class="btn btn-outline-success my-2 my-sm-0" type="submit" style="background-color:a3c2c2 ;">LOGIN</button>
</nav>
<div class="container  mt-5" style="background-color: #a3c2c2;">
  <div class="row">
    <div class="col">
      <div class="ps-4 mt-5">
      <form method="get" action="classes/logincheck.php">
        <div class="mb-5">
          <h1>Students Mangament System</h1>
        </div>
        <div class="form-group">
            <a href="Studentlogin.php"><h3 >Login AS Students</h3></a><br>
        </div>
        <div class="form-group">
            <a href="login.php" ><h3>Login AS Admin</h3></a><br><br>
        </div>
        <button type="submit" class="btn btn-primary">LOGIN</button>
      </form>
      </div>
    </div>
    <div class="col">
      <img src="img/download.jpeg" class="w-100" height="600px">
    </div>
  </div>
</div>
</body>
</html>