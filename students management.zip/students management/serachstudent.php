<?php include"C:/xampp/htdocs/students management/header.php";?>
<?php include 'classes/config.php'; ?>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="C:/xampp/htdocs/students management/assets/css/style1.css">
    </head>
    <body>
        <div class="container mt-5 mb-5 pb-5" style="background-color: #a3c2c2;">
            <div class="col">
                <h1><center>Serach Your Details</center></h1>
                <form method="GET" action="serachstudent.php">
                    <div class="form-group">
                        <label>Students ID</label>
                        <input type="text" name="id" class="form-control" placeholder="Name" id="id">
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
      
    </body>
</html>
<?php
 if (array_key_exists('id', $_GET))
 {
$id= $_GET['id']; 
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT id_students, firstname, semster,gender,branch FROM add_students WHERE id_students='$id'";
$result = $conn->query($sql);
$sql1 = "SELECT email ,addres, phone FROM personal_info WHERE id_students='$id'";
$result1 = $conn->query($sql1);


if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "<hr><h2>Your Details</h2> <hr> <ul><li> Students ID : ". $row["id_students"]."</li><br>";
    echo "<li>Name : ". $row["firstname"]."</li><br>";
    echo "<li>Semster : ". $row["semster"]."</li><br>";
    echo "<li>Gender : ". $row["gender"]."</li><br>";
    echo "<li>Branch : ". $row["branch"]."</li><br>";
      
  }
} else {
  echo "0 results";
}
if ($result1->num_rows > 0) {
  // output data of each row
  while($row = $result1->fetch_assoc()) {
    echo "<hr><h2>Personal Inforamation </h2> <hr> ";
   echo "<hr><li>Email : ". $row["email"]."</li><br>";
   echo "<li>Phone Number : ". $row["phone"]."</li><br>";
   echo "<li>Address : ". $row["addres"]."</li><br><hr>";
    
    
  }
} else {
  echo "0 results";
}


$conn->close();
}


?>